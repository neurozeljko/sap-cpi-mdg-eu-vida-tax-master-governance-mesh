import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {
    def reader = message.getBody(java.io.Reader)
    def payload = new JsonSlurper().parse(reader)

    String bpId = (payload.BusinessPartner ?: "").trim().toUpperCase()
    String countryCode = (payload.Country ?: "").trim().toUpperCase()
    String vatNumber = (payload.EuVatNumber ?: "").replaceAll("\\s+", "").toUpperCase()
    String peppolId = (payload.PeppolParticipantId ?: "").trim()
    String invoiceFormat = (payload.StructuredInvoiceFormat ?: "").trim().toUpperCase()
    String taxClassCode = (payload.TaxClassificationCode ?: "").trim()
    boolean vidaDrrReady = (payload.VidaDigitalReportingReady == true)

    List<String> taxViolations = []

    // 1. Validacija Business Partner ID-ja i EU VIES PDV broja (ukljucujuci ISO 7064 Mod 11,10 za DE)
    if (!bpId || bpId.length() < 3) {
        taxViolations.add("INVALID_BP_ID: BusinessPartner identifier is required for S/4HANA 2025 A_BusinessPartnerTaxNumber.")
    }
    if (!(countryCode ==~ ~/^[A-Z]{2}$/)) {
        taxViolations.add("INVALID_COUNTRY_CODE: ISO 3166-1 alpha-2 Country code is mandatory.")
    }
    if (!isValidEuVatNumber(countryCode, vatNumber)) {
        taxViolations.add("INVALID_EU_VIES_VAT: Failed EU VIES format or ISO 7064 Mod-11,10 check-digit verification for [${vatNumber}].")
    }

    // 2. Validacija ISO/IEC 6523 Peppol Participant ID-ja (ICD:Identifier)
    Set<String> validPeppolIcds = ["0204", "9930", "0199", "0088", "9914", "0208", "0106", "0009"] as Set
    if (!(peppolId ==~ ~/^\d{4}:[A-Za-z0-9\-_.]+$/)) {
        taxViolations.add("INVALID_PEPPOL_PARTICIPANT_ID: PeppolParticipantId [${peppolId}] must follow ISO/IEC 6523 ICD:Identifier syntax.")
    } else {
        String icdPrefix = peppolId.substring(0, 4)
        if (!validPeppolIcds.contains(icdPrefix)) {
            taxViolations.add("UNSUPPORTED_PEPPOL_ICD: ICD prefix [${icdPrefix}] is not registered in EU ViDA SMP directory.")
        }
    }

    // 3. EU ViDA (VAT in the Digital Age - Directive 2025/516) EN 16931 DRR provera
    Set<String> allowedFormats = ["EN16931_UBL_2.1", "EN16931_CII_D16B", "XRECHNUNG_3.0", "FACTUR_X_EN16931"] as Set
    if (!allowedFormats.contains(invoiceFormat)) {
        taxViolations.add("VIDA_UNSUPPORTED_EINVOICE_SYNTAX: StructuredInvoiceFormat [${invoiceFormat}] must comply with EN 16931 semantic model.")
    }
    if (!vidaDrrReady) {
        taxViolations.add("VIDA_DRR_NOT_ENABLED: Counterparty has not enabled real-time Digital Reporting Requirements (DRR) clearance.")
    }
    if (!(taxClassCode in ["0", "1"])) {
        taxViolations.add("INVALID_S4_TAX_CLASSIFICATION: TaxClassificationCode [${taxClassCode}] must be '1' (Liable) or '0' (Intra-Community Reverse Charge).")
    }

    // 4. Deterministicki SHA-256 Tax Compliance pecat
    String taxSeed = "${bpId}|${countryCode}|${vatNumber}|${peppolId}|${invoiceFormat}"
    String taxComplianceHash = MessageDigest.getInstance("SHA-256")
        .digest(taxSeed.getBytes("UTF-8"))
        .encodeHex()
        .toString()

    message.setHeader("X-TAX-Compliance-Hash", taxComplianceHash)

    if (!taxViolations.isEmpty()) {
        message.setHeader("X-TAX-Gate-Status", "REJECTED")
        def quarantineReport = [
            status: "QUARANTINED_VIDA_TAX_GOVERNANCE_HOLD",
            regulation: "EU_VIDA_DIRECTIVE_2025_516_AND_EN16931",
            timestamp: Instant.now().toString(),
            businessPartner: bpId,
            euVatNumber: vatNumber,
            taxComplianceSha256: taxComplianceHash,
            violations: taxViolations
        ]
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(quarantineReport)))
    } else {
        message.setHeader("X-TAX-Gate-Status", "APPROVED")
        def s4TaxPayload = [
            "@odata.context": "\$metadata#A_BusinessPartnerTaxNumber/\$entity",
            BusinessPartner: bpId,
            BPTaxType: "${countryCode}0",
            BPTaxNumber: vatNumber,
            TaxComplianceFingerprint: taxComplianceHash,
            to_TaxClassification: [
                DepartureCountry: countryCode,
                CustomerTaxCategory: "TTX1",
                TaxClassification: taxClassCode
            ],
            EuVidaDigitalReportingExtension: [
                VidaDirectiveStatus: "COMPLIANT_2026_2027",
                PeppolParticipantId: peppolId,
                StructuredInvoiceSyntax: invoiceFormat,
                DigitalReportingClearance: "ACTIVE",
                VerifiedAt: Instant.now().toString()
            ]
        ]
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(s4TaxPayload)))
    }

    return message
}

private boolean isValidEuVatNumber(String country, String vat) {
    if (!vat || !vat.startsWith(country)) return false
    if (country == "DE") {
        if (!(vat ==~ ~/^DE\d{9}$/)) return false
        String digits = vat.substring(2)
        int product = 10
        for (int i = 0; i < 8; i++) {
            int digit = Character.getNumericValue(digits.charAt(i))
            int sum = (digit + product) % 10
            if (sum == 0) sum = 10
            product = (2 * sum) % 11
        }
        int expectedCheck = (11 - product) % 10
        return expectedCheck == Character.getNumericValue(digits.charAt(8))
    }
    return (vat ==~ ~/^[A-Z]{2}[A-Z0-9]{2,12}$/)
}